// Modtager svar fra Ekkoly-appen, åbner platformens svarside og gemmer svaret,
// så siden kan sætte det ind. Udvidelsen sender aldrig selv noget til platformen.
import { trustedUrl } from './shared.js';

const MAX_AGE = 2 * 60 * 60 * 1000; // et svar ligger klar i 2 timer

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    if (msg?.type === 'reply') {
      // Kun fra appens egen side (content scriptet app-bridge), aldrig fra platformssider
      if (!sender.url || !isAppUrl(sender.url)) return respond({ ok: false, error: 'Ukendt afsender' });
      const { id, platform, url, text, author, snippet } = msg;
      if (typeof text !== 'string' || !text.trim() || text.length > 5000) return respond({ ok: false, error: 'Svaret mangler' });
      if (!trustedUrl(platform, url)) return respond({ ok: false, error: 'Linket hører ikke til platformen' });
      const pending = { id: String(id), platform, text, author: author ? String(author).slice(0, 80) : null, snippet: snippet ? String(snippet).slice(0, 200) : null, createdAt: Date.now() };
      await chrome.storage.session.set({ [`pending:${platform}`]: pending });
      await chrome.tabs.create({ url });
      return respond({ ok: true });
    }
    if (msg?.type === 'getPending') {
      const key = `pending:${msg.platform}`;
      const got = (await chrome.storage.session.get(key))[key];
      if (!got || Date.now() - got.createdAt > MAX_AGE) return respond({ pending: null });
      return respond({ pending: got });
    }
    if (msg?.type === 'done' || msg?.type === 'dismiss') {
      const key = `pending:${msg.platform}`;
      const got = (await chrome.storage.session.get(key))[key];
      await chrome.storage.session.remove(key);
      // Appen får besked, så anmeldelsen kan markeres som besvaret
      if (msg.type === 'done' && got) await chrome.storage.local.set({ lastDone: { id: got.id, at: Date.now() } });
      return respond({ ok: true });
    }
    respond({ ok: false });
  })();
  return true; // svarer asynkront
});

function isAppUrl(u) {
  try {
    const url = new URL(u);
    if (url.protocol !== 'https:') return false;
    if (url.hostname === 'jannie-spec.github.io') return url.pathname.startsWith('/gaesternes-stemme-app/');
    return ['ekkoly.com', 'ekkoly.dk'].some((d) => url.hostname === d || url.hostname.endsWith(`.${d}`));
  } catch { return false; }
}
