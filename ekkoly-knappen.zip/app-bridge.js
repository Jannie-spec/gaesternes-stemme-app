// Bro mellem Ekkoly-appen (siden) og udvidelsen. Kører kun på appens egne adresser.
(() => {
  document.documentElement.dataset.ekkolyExtension = chrome.runtime.getManifest().version;
  window.postMessage({ source: 'ekkoly-ext', type: 'ready', version: chrome.runtime.getManifest().version }, location.origin);

  window.addEventListener('message', (e) => {
    if (e.source !== window || e.origin !== location.origin) return;
    const m = e.data;
    if (!m || m.source !== 'ekkoly-app' || m.type !== 'reply') return;
    chrome.runtime.sendMessage({ type: 'reply', id: m.id, platform: m.platform, url: m.url, text: m.text, author: m.author, snippet: m.snippet }, (res) => {
      window.postMessage({ source: 'ekkoly-ext', type: 'reply-ack', id: m.id, ok: Boolean(res?.ok), error: res?.error ?? chrome.runtime.lastError?.message ?? null }, location.origin);
    });
  });

  // Når medarbejderen har trykket "Svaret er sendt" på platformen
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.lastDone?.newValue) {
      window.postMessage({ source: 'ekkoly-ext', type: 'reply-done', id: changes.lastDone.newValue.id }, location.origin);
    }
  });
})();
