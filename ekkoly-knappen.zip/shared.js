// Fælles for udvidelsen: hvilke domæner hører til hvilken platform.
// Holdes i takt med web/js/platforms.js i appen.
export const DOMAINS = {
  google: ['google.com', 'google.dk'], trustpilot: ['trustpilot.com'],
    booking: ['booking.com'], expedia: ['expediapartnercentral.com', 'expedia.com'], vrbo: ['vrbo.com'],
  airbnb: ['airbnb.com', 'airbnb.dk', 'airbnb.de'], tripadvisor: ['tripadvisor.com', 'tripadvisor.dk', 'tripadvisor.de', 'tripadvisor.co.uk'],
  hostelworld: ['hostelworld.com'], agoda: ['agoda.com'], holidaycheck: ['holidaycheck.de', 'holidaycheck.com'],
  tripcom: ['trip.com'], thefork: ['thefork.com'],
};

export function platformForHost(hostname) {
  for (const [p, list] of Object.entries(DOMAINS)) {
    if (list.some((d) => hostname === d || hostname.endsWith(`.${d}`))) return p;
  }
  return null;
}

export function trustedUrl(platform, url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && platformForHost(u.hostname) === platform;
  } catch { return false; }
}
