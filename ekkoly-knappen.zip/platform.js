// Kører på platformenes egne sider (Booking.com, Airbnb, Tripadvisor ...).
// Ligger der et svar fra Ekkoly til denne platform, vises et lille panel, som sætter svaret
// ind i platformens svarfelt. Udvidelsen trykker aldrig selv "Send": det gør medarbejderen.
(() => {
  const DOMAINS = {
    google: ['google.com', 'google.dk'], trustpilot: ['trustpilot.com'],
    booking: ['booking.com'], expedia: ['expediapartnercentral.com', 'expedia.com'], vrbo: ['vrbo.com'],
    airbnb: ['airbnb.com', 'airbnb.dk', 'airbnb.de'], tripadvisor: ['tripadvisor.com', 'tripadvisor.dk', 'tripadvisor.de', 'tripadvisor.co.uk'],
    hostelworld: ['hostelworld.com'], agoda: ['agoda.com'], holidaycheck: ['holidaycheck.de', 'holidaycheck.com'],
    tripcom: ['trip.com'], thefork: ['thefork.com'],
  };
  const NAMES = { google: 'Google', trustpilot: 'Trustpilot', booking: 'Booking.com', expedia: 'Expedia', vrbo: 'Vrbo', airbnb: 'Airbnb', tripadvisor: 'Tripadvisor', hostelworld: 'Hostelworld', agoda: 'Agoda', holidaycheck: 'HolidayCheck', tripcom: 'Trip.com', thefork: 'TheFork' };
  const host = location.hostname;
  const platform = Object.keys(DOMAINS).find((p) => DOMAINS[p].some((d) => host === d || host.endsWith(`.${d}`)));
  if (!platform || window.top !== window) return;

  let pending = null;
  let panel = null;

  const ask = (msg) => new Promise((res) => chrome.runtime.sendMessage(msg, (r) => res(r)));

  async function check() {
    const r = await ask({ type: 'getPending', platform });
    pending = r?.pending ?? null;
    if (pending && !panel) show();
    if (!pending && panel) { panel.remove(); panel = null; }
  }

  // ---- Find svarfeltet ------------------------------------------------------
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 40 && r.height > 18 && s.visibility !== 'hidden' && s.display !== 'none' && !el.disabled && !el.readOnly;
  };
  const isSearch = (el) => /search|søg|suche|query|filter/i.test(`${el.name} ${el.id} ${el.placeholder ?? ''} ${el.getAttribute('aria-label') ?? ''} ${el.type ?? ''}`);

  function candidates() {
    const list = [...document.querySelectorAll('textarea, [contenteditable="true"], [contenteditable=""], [role="textbox"]')]
      .filter((el) => visible(el) && !isSearch(el) && !el.closest('#ekkoly-panel-host'));
    return list;
  }

  // Det element, der indeholder et stykke af gæstens tekst, så vi vælger svarfeltet ved den rigtige anmeldelse
  function reviewAnchor() {
    if (!pending?.snippet) return null;
    const needle = pending.snippet.replace(/\s+/g, ' ').trim().slice(0, 40).toLowerCase();
    if (needle.length < 12) return null;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      if (n.nodeValue && n.nodeValue.replace(/\s+/g, ' ').toLowerCase().includes(needle)) return n.parentElement;
    }
    return null;
  }

  function distance(a, b) {
    const pa = [], pb = new Set();
    for (let x = a; x; x = x.parentElement) pa.push(x);
    for (let x = b; x; x = x.parentElement) pb.add(x);
    const common = pa.findIndex((x) => pb.has(x));
    return common < 0 ? 1e9 : common;
  }

  function pickField() {
    const list = candidates();
    if (!list.length) return null;
    const active = document.activeElement;
    if (active && list.includes(active)) return active;
    const anchor = reviewAnchor();
    if (anchor) return list.slice().sort((x, y) => distance(x, anchor) - distance(y, anchor))[0];
    const empty = list.filter((el) => !(el.value ?? el.textContent ?? '').trim());
    return (empty.length === 1 ? empty[0] : list.length === 1 ? list[0] : null);
  }

  function fill(el, text) {
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      // Platformene bruger ofte React: sæt værdien via den indbyggede setter og send input-hændelser
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      const sel = window.getSelection();
      sel.selectAllChildren(el);
      document.execCommand('insertText', false, text);
      if ((el.textContent ?? '').trim() !== text.trim()) { el.textContent = text; el.dispatchEvent(new InputEvent('input', { bubbles: true })); }
    }
    el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  // ---- Panelet ---------------------------------------------------------------
  function show() {
    const hostEl = document.createElement('div');
    hostEl.id = 'ekkoly-panel-host';
    const root = hostEl.attachShadow({ mode: 'open' });
    const name = NAMES[platform] ?? platform;
    root.innerHTML = `
      <style>
        :host { all: initial; }
        .p { position: fixed; right: 16px; bottom: 16px; z-index: 2147483647; width: min(360px, calc(100vw - 32px));
          background: #fff; color: #1e2b30; border: 1px solid #b9c4c1; border-radius: 10px; box-shadow: 0 10px 30px rgba(30,43,48,.25);
          font: 14px/1.45 -apple-system, "Segoe UI", Helvetica, Arial, sans-serif; padding: 14px 16px; }
        h2 { margin: 0 0 6px; font: 600 15px/1.3 Georgia, serif; }
        p { margin: 0 0 8px; }
        .muted { color: #5c6a6f; font-size: 13px; }
        .txt { max-height: 120px; overflow: auto; background: #f3f5f4; border-radius: 6px; padding: 8px 10px; white-space: pre-wrap; font-size: 13px; margin-bottom: 10px; }
        .row { display: flex; gap: 8px; flex-wrap: wrap; }
        button { font: 600 14px/1 inherit; border-radius: 6px; padding: 10px 12px; cursor: pointer; border: 1px solid #b9c4c1; background: #fff; color: #1e2b30; }
        button.primary { background: #2b5e7e; border-color: #2b5e7e; color: #fff; }
        button.link { border: 0; background: none; padding: 10px 4px; color: #5c6a6f; text-decoration: underline; font-weight: 400; }
        .msg { margin-top: 8px; font-size: 13px; }
        .msg.err { color: #8e2f3c; }
        :focus-visible { outline: 3px solid #2b5e7e; outline-offset: 2px; }
      </style>
      <div class="p" role="dialog" aria-label="Ekkoly">
        <h2>Svar fra Ekkoly</h2>
        <p class="muted"></p>
        <div class="txt"></div>
        <div class="row">
          <button class="primary" id="insert">Indsæt svaret</button>
          <button id="copy">Kopiér</button>
        </div>
        <div class="row" style="margin-top:6px">
          <button class="link" id="done">Svaret er sendt</button>
          <button class="link" id="close">Luk</button>
        </div>
        <p class="msg" role="status"></p>
      </div>`;
    root.querySelector('.muted').textContent = `${pending.author ? `Til ${pending.author} på ${name}.` : `Til gæsten på ${name}.`} Indsæt svaret, læs det igennem, og tryk så på ${name}s egen Send-knap.`;
    root.querySelector('.txt').textContent = pending.text;
    const msg = root.querySelector('.msg');
    const say = (t, err = false) => { msg.textContent = t; msg.className = `msg${err ? ' err' : ''}`; };

    root.querySelector('#insert').addEventListener('click', () => {
      const field = pickField();
      if (!field) return say(`Find anmeldelsen og klik på ${name}s "Svar"-knap, så svarfeltet åbner. Tryk så "Indsæt svaret" igen.`, true);
      fill(field, pending.text);
      say(`Svaret er sat ind. Læs det igennem, og tryk på ${name}s Send-knap.`);
    });
    root.querySelector('#copy').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(pending.text); say('Kopieret.'); } catch { say('Kunne ikke kopiere. Markér teksten og kopiér selv.', true); }
    });
    root.querySelector('#done').addEventListener('click', async () => {
      await ask({ type: 'done', platform });
      say('Tak. Ekkoly markerer anmeldelsen som besvaret.');
      setTimeout(() => { hostEl.remove(); panel = null; }, 1500);
    });
    root.querySelector('#close').addEventListener('click', async () => {
      hostEl.remove(); panel = null;
      await ask({ type: 'dismiss', platform });
    });
    document.documentElement.appendChild(hostEl);
    panel = hostEl;
  }

  check();
  // Platformene er ofte enkeltsideapps: tjek igen, når fanen bliver aktiv
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
})();
